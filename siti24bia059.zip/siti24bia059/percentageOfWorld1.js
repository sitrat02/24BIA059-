// Function Declaration
function percentageOfWorld1(population) {
    return (population / 7900) * 100;
}

// Calling percentageOfWorld1
const tanzania1 = percentageOfWorld1(67);
const kenya1 = percentageOfWorld1(55);
const finland1 = percentageOfWorld1(6);

console.log("Function Declaration:");
console.log(tanzania1);
console.log(kenya1);
console.log(finland1);


// Function Expression
const percentageOfWorld2 = function(population) {
    return (population / 7900) * 100;
};

// Calling percentageOfWorld2
const tanzania2 = percentageOfWorld2(67);
const kenya2 = percentageOfWorld2(55);
const finland2 = percentageOfWorld2(6);

console.log("Function Expression:");
console.log(tanzania2);
console.log(kenya2);
console.log(finland2);


// Arrow Function
const percentageOfWorld3 = (population) => {
    return (population / 7900) * 100;
};

// Calling percentageOfWorld3
const tanzania3 = percentageOfWorld3(67);
const kenya3 = percentageOfWorld3(55);
const finland3 = percentageOfWorld3(6);

console.log("Arrow Function:");
console.log(tanzania3);
console.log(kenya3);
console.log(finland3);
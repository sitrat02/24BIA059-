// Function definition
function describeCountry(country, population, capitalCity) {
    return `${country} has ${population} million people and its capital city is ${capitalCity}`;
}

// Calling the function 3 times
const finland = describeCountry("Finland", 6, "Helsinki");
const tanzania = describeCountry("Tanzania", 67, "Dodoma");
const kenya = describeCountry("Kenya", 55, "Nairobi");

// Logging to the console
document.write(finland);
document.write(tanzania);
document.write(kenya);